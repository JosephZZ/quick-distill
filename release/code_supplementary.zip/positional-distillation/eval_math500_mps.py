"""
MPS port of eval_math500.py — HF batched generate instead of vLLM.

Usage:
    python eval_math500_mps.py \
        --base_model Qwen/Qwen2.5-Math-1.5B \
        --lora_path checkpoints/.../step_50 \
        --output_dir checkpoints/.../eval_step_50 \
        --n_samples 1 --temperature 0.0 --batch_size 8

Scoring matches eval_math500.py: pass@n, maj@n, avg@n via math_equal grader.
"""

import json
import os
import sys
import re
import argparse
import time
from collections import Counter

import torch
from datasets import load_dataset
from transformers import AutoTokenizer, AutoModelForCausalLM
from peft import PeftModel

_repo_dir = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, os.path.join(_repo_dir, "math_eval_stub"))
from grader import math_equal


def last_boxed_only_string(s):
    idx = s.rfind("\\boxed")
    if "\\boxed " in s:
        return "\\boxed " + s.split("\\boxed ")[-1].split("$")[0]
    if idx < 0:
        idx = s.rfind("\\fbox")
        if idx < 0:
            return None
    i = idx
    right = None
    n = 0
    while i < len(s):
        if s[i] == "{":
            n += 1
        if s[i] == "}":
            n -= 1
            if n == 0:
                right = i
                break
        i += 1
    return None if right is None else s[idx:right + 1]


def remove_boxed(s):
    if s is None:
        return None
    if "\\boxed " in s:
        if s[:len("\\boxed ")] == "\\boxed ":
            return s[len("\\boxed "):]
    left = "\\boxed{"
    try:
        assert s[:len(left)] == left
        assert s[-1] == "}"
        return s[len(left):-1]
    except (AssertionError, IndexError):
        return None


def extract_answer(text):
    try:
        s = last_boxed_only_string(text)
        if s is None:
            return None
        return remove_boxed(s)
    except Exception:
        return None


def normalize_for_vote(a):
    if a is None:
        return None
    return re.sub(r"\s+", " ", str(a)).strip()


def main():
    p = argparse.ArgumentParser()
    p.add_argument("--base_model", required=True)
    p.add_argument("--lora_path", default=None, help="Optional LoRA adapter path")
    p.add_argument("--output_dir", required=True)
    p.add_argument("--dataset", default="HuggingFaceH4/MATH-500")
    p.add_argument("--split", default="test")
    p.add_argument("--n_samples", type=int, default=1)
    p.add_argument("--temperature", type=float, default=0.0)
    p.add_argument("--top_p", type=float, default=1.0)
    p.add_argument("--max_new_tokens", type=int, default=2048)
    p.add_argument("--batch_size", type=int, default=8, help="problems per batch")
    p.add_argument("--limit", type=int, default=0, help="debug: only eval first N problems")
    args = p.parse_args()

    device = "mps"
    os.makedirs(args.output_dir, exist_ok=True)

    print(f"Loading base {args.base_model}...")
    tok = AutoTokenizer.from_pretrained(args.base_model, trust_remote_code=True, use_fast=True)
    if tok.pad_token_id is None:
        tok.pad_token_id = tok.eos_token_id
    tok.padding_side = "left"

    model = AutoModelForCausalLM.from_pretrained(
        args.base_model, dtype=torch.bfloat16, trust_remote_code=True
    )
    if args.lora_path:
        print(f"Loading LoRA {args.lora_path}...")
        model = PeftModel.from_pretrained(model, args.lora_path)
        model = model.merge_and_unload()
    model.to(device).eval()

    print(f"Loading dataset {args.dataset} / {args.split}...")
    ds = load_dataset(args.dataset, trust_remote_code=True, split=args.split)
    if args.limit > 0:
        ds = ds.select(range(min(args.limit, len(ds))))

    instruction = "Let's think step by step and output the final answer within \\boxed{}."
    prompts, gts, questions = [], [], []
    for ex in ds:
        q = ex["problem"] + " " + instruction
        kwargs = dict(tokenize=False, add_generation_prompt=True)
        try:
            prompt = tok.apply_chat_template(
                [{"role": "user", "content": q}], enable_thinking=False, **kwargs
            )
        except TypeError:
            prompt = tok.apply_chat_template([{"role": "user", "content": q}], **kwargs)
        prompts.append(prompt)
        gts.append(extract_answer(ex["solution"]))
        questions.append(ex["problem"])

    total = len(prompts)
    print(f"Generating {total} × n={args.n_samples} responses (batch_size={args.batch_size})...")

    results_path = os.path.join(args.output_dir, "results.jsonl")
    f_out = open(results_path, "w")

    do_sample = args.temperature > 0
    pass_c = maj_c = 0
    avg_sum = 0.0
    sample_correct = sample_total = 0
    t0 = time.time()

    for batch_start in range(0, total, args.batch_size):
        batch_end = min(batch_start + args.batch_size, total)
        batch_prompts = prompts[batch_start:batch_end]
        enc = tok(batch_prompts, return_tensors="pt", padding=True, truncation=False).to(device)

        all_samples = [[] for _ in range(len(batch_prompts))]
        for s in range(args.n_samples):
            with torch.inference_mode():
                gen_ids = model.generate(
                    **enc,
                    max_new_tokens=args.max_new_tokens,
                    do_sample=do_sample,
                    temperature=args.temperature if do_sample else 1.0,
                    top_p=args.top_p,
                    pad_token_id=tok.pad_token_id,
                )
            new_ids = gen_ids[:, enc["input_ids"].shape[1]:]
            texts = tok.batch_decode(new_ids, skip_special_tokens=True)
            for i, t in enumerate(texts):
                all_samples[i].append(t)

        for i, samples in enumerate(all_samples):
            idx = batch_start + i
            gt = gts[idx]
            response_evals = []
            flags = []
            for resp in samples:
                extracted = extract_answer(resp)
                ok = math_equal(extracted, gt, timeout=True) if (extracted is not None and gt is not None) else False
                flags.append(ok)
                response_evals.append({
                    "response": resp, "extracted_answer": extracted, "is_correct": ok,
                })
            pass_hit = any(flags)
            if pass_hit:
                pass_c += 1
            n = len(flags)
            sample_total += n
            sample_correct += sum(flags)
            avg_hit = sum(flags) / n if n else 0.0
            avg_sum += avg_hit

            # maj@n
            votes = Counter()
            first_pos = {}
            repr_ans = {}
            for j, r in enumerate(response_evals):
                key = normalize_for_vote(r["extracted_answer"])
                if not key:
                    continue
                votes[key] += 1
                if key not in first_pos:
                    first_pos[key] = j
                    repr_ans[key] = r["extracted_answer"]
            maj_ans = None
            maj_hit = False
            if votes:
                best = max(votes.values())
                cands = [k for k, c in votes.items() if c == best]
                k = sorted(cands, key=lambda x: first_pos[x])[0]
                maj_ans = repr_ans[k]
                maj_hit = math_equal(maj_ans, gt, timeout=True) if gt is not None else False
            if maj_hit:
                maj_c += 1

            f_out.write(json.dumps({
                "idx": idx, "question": questions[idx], "ground_truth": gt,
                "responses": response_evals,
                "pass_correct": pass_hit, "maj_answer": maj_ans, "maj_correct": maj_hit,
                "avg_correct": avg_hit,
            }, ensure_ascii=False) + "\n")
            f_out.flush()

        done = batch_end
        elapsed = time.time() - t0
        rate = done / max(elapsed, 1e-9)
        eta = (total - done) / max(rate, 1e-9)
        print(f"  [{done}/{total}] pass={pass_c/done:.4f} "
              f"maj={maj_c/done:.4f} avg={avg_sum/done:.4f} "
              f"elapsed={elapsed:.0f}s eta={eta:.0f}s")

    f_out.close()
    summary = {
        "base_model": args.base_model,
        "lora_path": args.lora_path,
        "dataset": args.dataset, "split": args.split,
        "total": total,
        "pass_correct": pass_c, "pass_accuracy": pass_c / total,
        "maj_correct": maj_c, "maj_accuracy": maj_c / total,
        "avg_accuracy": avg_sum / total,
        "sample_correct_total": sample_correct, "sample_total": sample_total,
        "n_samples": args.n_samples, "temperature": args.temperature,
    }
    with open(os.path.join(args.output_dir, "summary.json"), "w") as f:
        json.dump(summary, f, indent=2)
    print(f"\nMATH-500  pass@{args.n_samples}={summary['pass_accuracy']:.4f}  "
          f"maj@{args.n_samples}={summary['maj_accuracy']:.4f}  "
          f"avg@{args.n_samples}={summary['avg_accuracy']:.4f}")
    print(f"Saved to {args.output_dir}")


if __name__ == "__main__":
    main()
