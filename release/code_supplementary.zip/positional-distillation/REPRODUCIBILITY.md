# Reproducibility notes (AAAI Reproducibility Checklist mapping)

Where each code/experiment-related checklist item is addressed in this package:

- **Data pre-processing code included** — `scripts/prepare_funcall_data.py` (function-calling data); math/coding training data are loaded directly from the Hugging Face Hub inside `on_policy_distill_positional.py` (no offline pre-processing).
- **All source code for conducting experiments included** — training (`on_policy_distill_positional.py`, run scripts under `scripts/`), evaluation (`eval_math500.py`, `scripts/eval_humaneval.py`, `eval_funcall.py`), and metric aggregation (`scripts/compute_metrics.py`).
- **All source code for analyzing experiments included** — `scripts/analysis/` reproduces the per-position KL, token-classification, degradation, and cascade analyses.
- **Public availability with research-permissive license** — MIT license included; the repository will be released publicly upon publication.
- **Randomness / seeds** — `--seed` (default 42) seeds Python `random` and `torch` in training; evaluation sampling uses vLLM seed 42. Reported eval metrics are avg@4 / maj@4 / pass@4 over 4 samples per problem (temperature 0.7) for math and greedy pass@1 for coding.
- **Computing infrastructure** — see "Compute infrastructure" in `README.md`; exact library versions pinned in `requirements.txt` (Python 3.12.3, Linux).
- **Final hyperparameters** — "Hyperparameters used in the paper" table in `README.md`; each run script under `scripts/` records the exact command line of the corresponding experiment.
- **Number of runs** — one training run per configuration; robustness is assessed across 8 training steps × 8 position limits × 2 batch configurations × 2 training methods (see paper's limitations discussion).
