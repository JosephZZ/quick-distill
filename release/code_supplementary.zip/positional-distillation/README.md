# Positional Distillation

Code for the AAAI submission **"Positional Distillation: Computing Loss on Early Tokens Is Sufficient for On-Policy Knowledge Distillation"** (anonymous).

On-policy knowledge distillation trains a student on reverse KL against a teacher over the student's own generations. We show that teacher–student KL divergence is heavily front-loaded (reasoning-strategy tokens), and that computing the loss **only on the first N response tokens** matches or exceeds full-sequence distillation while eliminating its training instability — implemented as a single loss mask.

## Repository layout

```
on_policy_distill_positional.py       Main training script (CUDA). Generation via HF generate,
                                      vLLM (--use_vllm) or SGLang; reverse-KL loss on first N
                                      positions; LoRA or full fine-tune; progressive mode.
on_policy_distill_positional_mps.py   Apple Silicon (MPS) port of the trainer (single device).
vllm_generate.py                      vLLM generation subprocess (used by eval and --use_vllm).
eval_math500.py / eval_math500_mps.py MATH-500 evaluation (avg@k / maj@k / pass@k).
eval_funcall.py                       Function-calling (BFCL-style) evaluation.
math_eval_stub/grader.py              Math answer-equivalence grader (adapted from public
                                      MATH/ToRA/DeepSeek-Math evaluation code; see header).
data/
  smoke_problems.jsonl                Tiny problem set for smoke tests.
  funcall/{train,eval_bfcl}.jsonl     Function-calling data (built by scripts/prepare_funcall_data.py
                                      from the public Glaive function-calling dataset).
scripts/
  experiments/run_all_experiments.sh  End-to-end driver for the paper's main experiments
                                      (math + coding, positional vs. full-seq, LoRA vs. FullFT).
  experiments/run_scaling_gpu*.sh     Scaling experiments across model pairs.
  run_pair*.sh                        Larger student/teacher pairs (14B/32B students, 72B teacher).
  run_gemma2_qwen3_*.sh               Cross-tokenizer pair (Gemma-2 student, Qwen3 teacher).
  run_qwen34b_qwen35b_pos200_bs16.sh  Qwen3-4B student / Qwen3.5-35B teacher run.
  run_token_select_phase1_k100.sh     Token-selection (top-K KL) variant.
  eval_pair_step.sh / eval_all_pairs.sh  Checkpoint merging + MATH-500 eval helpers.
  eval_humaneval.py                   HumanEval/MBPP(+) evaluation via evalplus.
  compute_metrics.py                  Aggregate eval summaries into result tables.
  timing_benchmark.py                 Wall-clock timing of positional vs. full-seq steps.
  prepare_funcall_data.py             Builds data/funcall/ from the Glaive dataset.
  analysis/                           Analysis code for the paper's Section 4 / cascade results:
    kl_analysis_v3.py                   per-position KL over on-policy trajectories
    kl_after200_analysis{,_v2}.py       KL by position range, beyond trained range
    token_classification_analysis.py    token-category KL (planning vs. math tokens)
    fullseq_degradation_analysis.py     \boxed{} repetition / degradation statistics
    analyze_generation_behavior.py      cascade-effect behavioral analysis (Jaccard, structure)
    strategy_*.py                       KL/mass coverage analyses for token-selection strategies
```

## Installation

Python 3.12, CUDA GPU(s) with bf16 support (the MPS trainer runs on Apple Silicon).

```bash
pip install -r requirements.txt
```

Models and datasets are downloaded from the Hugging Face Hub by name. Set `HF_HOME` if you want a custom cache location. If you use local snapshot directories instead, see `scripts/hf_models_env.sh`.

## Quickstart

Smoke test (small models, a few steps):

```bash
python on_policy_distill_positional.py \
  --student_model Qwen/Qwen2.5-Math-1.5B --teacher_model Qwen/Qwen3-1.7B \
  --dataset AI-MO/NuminaMath-CoT --num_problems 16 \
  --bs 4 --n_samples 1 --position_limit 50 --max_new_tokens 50 \
  --output_dir checkpoints/smoke
```

Main paper experiments (math + coding, all position limits, LoRA and full fine-tune), designed for a 2-GPU machine:

```bash
bash scripts/experiments/run_all_experiments.sh
```

Evaluation of a checkpoint on MATH-500 (LoRA checkpoints must be merged first; `eval_pair_step.sh` does merge + eval in one call):

```bash
python eval_math500.py --model <merged_model_path_or_hf_name> --n_samples 4 --temperature 0.7
```

Coding eval: `python scripts/eval_humaneval.py --model <path> --dataset humaneval` (and `mbpp`).

## Key training arguments

- `--position_limit N` — compute reverse-KL loss only on the first N response tokens (0 = full sequence). **This is the method.** `--max_new_tokens` is auto-clamped to N so only N tokens are generated.
- `--progressive_position` — progressive variant: N grows linearly from 1 to `--position_limit` over training.
- `--token_select_mode {prefix,top_kl,top_entropy_student,window}` — prefix (positional, default) vs. top-K / window token-selection variants.
- `--full_finetune` — full fine-tune instead of LoRA.
- `--use_vllm` / SGLang flags — fast generation backends for full-sequence runs.
- `--seed` — random seed (default 42; seeds Python `random` and `torch`).

## Hyperparameters used in the paper

| | LoRA | Full fine-tune |
|---|---|---|
| LoRA config | r=32, alpha=64, q/k/v/o/gate/up/down_proj | — |
| Learning rate | 5e-5 | 5e-6 |
| Sampling temperature | 0.7 | 0.7 |
| Math training | 3200 problems (NuminaMath-CoT), n_samples=1, bs=16, 200 steps | same |
| Coding training | 6400 problems (CodeUltraFeedback), n_samples=1, bs=16, 400 steps | same |
| Position limits swept | 5, 10, 20, 50, 100, 150, 200, full-seq | 50…full-seq |
| Checkpoints | every 50 steps | every 50 steps |

Evaluation: MATH-500 with n_samples=4, temperature=0.7 (avg@4 / maj@4 / pass@4, vLLM seed 42); HumanEval/MBPP(+) with greedy decoding (temperature=0.0, pass@1) via evalplus.

## Reproducing the main numbers

Student Qwen2.5-Math-1.5B, teacher Qwen3-1.7B, MATH-500 (LoRA, n1bs16):

| Method | Best step | avg@4 | maj@4 | pass@4 |
|--------|-----------|-------|-------|--------|
| Baseline (no distill) | — | 50.95 | 61.2 | 72.8 |
| Pos-50 | 150 | **66.65** | 71.0 | 81.0 |
| Pos-100 | 200 | 65.85 | 70.8 | 79.8 |
| Pos-200 | 50 | 66.05 | 71.2 | 81.0 |
| Full-seq (first-boxed) | 50 | 65.55 | — | 80.0 |

Coding (HumanEval pass@1, LoRA): pos-50/pos-100 peak at 42.1; full-seq peaks at 40.2 (step 50) and degrades monotonically to 26.8 by step 400.

The KL-analysis figures (per-position KL, token classification, cascade effect) are produced by `scripts/analysis/`; each script writes a markdown/JSON report and plots.

## Known gotchas

- **LoRA merge for eval**: `eval_math500.py` takes a merged model path, not a LoRA adapter. Merge on CPU (`CUDA_VISIBLE_DEVICES=""`) to keep GPU memory free for vLLM; `scripts/eval_pair_step.sh` handles this.
- **Full-seq answer extraction**: full-sequence-distilled models degenerate into repeating `\boxed{}` many times; use first-boxed extraction (supported in the eval script) for accurate scoring — this is the degradation phenomenon analyzed in the paper.
- **vLLM GPU memory**: with trainer models resident, use `gpu_memory_utilization≈0.5`; on a free GPU, 0.85.

## Compute infrastructure

Experiments were run on Linux (Ubuntu, kernel 6.8) machines with NVIDIA GPUs: 2×48GB (A6000-class) for the main 1.5B/1.7B experiments, and 8-GPU nodes for the 14B/32B-student, 72B-teacher scaling runs. Software versions are pinned in `requirements.txt`.

## License

MIT (see `LICENSE`). `math_eval_stub/grader.py` adapts public evaluation code; attribution in its header. Datasets used (NuminaMath-CoT, CodeUltraFeedback, MATH-500, HumanEval/MBPP, Glaive function-calling) are public with research-permissive licenses and are downloaded from their original sources.
