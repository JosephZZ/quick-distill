#!/usr/bin/env bash
# Orchestrator: 4 configs × 4 steps = 16 evals across 8 GPUs.
# Strategy: assign GPUs round-robin from a free pool. When a GPU's worker finishes,
# release it back to the pool and start the next pending job on it.
set -uo pipefail

BASE="$(cd "$(dirname "$0")/.." && pwd)"
WORKER="$BASE/scripts/eval_pair_step.sh"
ORCH_LOG="$BASE/logs/eval/orchestrator.log"
mkdir -p "$BASE/logs/eval"

CONFIGS=(
  "pair1-14b-72b-prefix100"
  "pair1-14b-72b-fullseq"
  "pair2-32b-72b-prefix100"
  "pair2-32b-72b-fullseq"
)
STEPS=(50 100 150 200)

# Build job list. Earlier-completing jobs first: smaller models and earlier steps.
# Order by (config_idx, step) so 14B finishes before 32B starts loading too much.
JOBS=()
for CFG in "${CONFIGS[@]}"; do
  for S in "${STEPS[@]}"; do
    JOBS+=("$CFG:$S")
  done
done

# GPUs to use. Smoke test occupies GPU 0 for now -- skip 0 by default; override via EVAL_GPUS env.
GPUS=(${EVAL_GPUS:-1 2 3 4 5 6 7})
NUM_GPUS=${#GPUS[@]}

echo "[$(date -Is)] orchestrator start: ${#JOBS[@]} jobs, GPUs: ${GPUS[*]}" | tee -a "$ORCH_LOG"

declare -A PID_TO_JOB
declare -A PID_TO_GPU
FREE_GPUS=("${GPUS[@]}")
PENDING=("${JOBS[@]}")

# Launch initial wave
launch_one() {
  local job="$1"
  local gpu="$2"
  local cfg="${job%:*}"
  local step="${job##*:}"
  local logfile="$BASE/logs/eval/orch-${cfg}-step${step}-gpu${gpu}.log"
  echo "[$(date -Is)] LAUNCH $cfg step_$step on GPU $gpu" | tee -a "$ORCH_LOG"
  bash "$WORKER" "$cfg" "$step" "$gpu" > "$logfile" 2>&1 &
  local pid=$!
  PID_TO_JOB[$pid]="$job"
  PID_TO_GPU[$pid]="$gpu"
}

# Initial fill
while [ ${#FREE_GPUS[@]} -gt 0 ] && [ ${#PENDING[@]} -gt 0 ]; do
  gpu="${FREE_GPUS[0]}"
  FREE_GPUS=("${FREE_GPUS[@]:1}")
  job="${PENDING[0]}"
  PENDING=("${PENDING[@]:1}")
  launch_one "$job" "$gpu"
done

# Wait loop
while [ ${#PID_TO_JOB[@]} -gt 0 ]; do
  # Find any finished child
  for pid in "${!PID_TO_JOB[@]}"; do
    if ! kill -0 "$pid" 2>/dev/null; then
      wait "$pid" 2>/dev/null; rc=$?
      job="${PID_TO_JOB[$pid]}"
      gpu="${PID_TO_GPU[$pid]}"
      unset PID_TO_JOB[$pid]
      unset PID_TO_GPU[$pid]
      if [ $rc -eq 0 ]; then
        echo "[$(date -Is)] DONE $job (GPU $gpu)" | tee -a "$ORCH_LOG"
      else
        echo "[$(date -Is)] FAIL $job (GPU $gpu, rc=$rc)" | tee -a "$ORCH_LOG"
      fi
      # Launch next pending job on the freed GPU
      if [ ${#PENDING[@]} -gt 0 ]; then
        next="${PENDING[0]}"
        PENDING=("${PENDING[@]:1}")
        launch_one "$next" "$gpu"
      else
        FREE_GPUS+=("$gpu")
      fi
    fi
  done
  sleep 5
done

echo "[$(date -Is)] orchestrator: all jobs finished" | tee -a "$ORCH_LOG"
