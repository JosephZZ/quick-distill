#!/usr/bin/env bash
# Single-step eval worker: takes (RUN, STEP, GPU), merges LoRA on CPU, runs vLLM eval, deletes merged dir.
# Skips work if summary.json already exists.
set -eo pipefail

if [ "$#" -ne 3 ]; then
  echo "Usage: $0 <RUN> <STEP> <GPU>" >&2
  echo "  e.g. $0 pair1-14b-72b-prefix100 50 0" >&2
  exit 2
fi

RUN=$1
STEP=$2
GPU=$3

BASE="$(cd "$(dirname "$0")/.." && pwd)"
CKPT_DIR="$BASE/checkpoints/$RUN"
LORA_DIR="$CKPT_DIR/step_$STEP"
MERGED_DIR="$CKPT_DIR/_eval_merged_step_$STEP"
EVAL_DIR="$BASE/eval_results/$RUN/step_$STEP"
LOG="$BASE/logs/eval/${RUN}-step${STEP}.log"

mkdir -p "$BASE/logs/eval" "$BASE/eval_results/$RUN"

if [ -f "$EVAL_DIR/summary.json" ]; then
  echo "[$(date -Is)] [$RUN step_$STEP gpu$GPU] SKIP (summary.json exists)"
  exit 0
fi

if [ ! -f "$LORA_DIR/adapter_model.safetensors" ]; then
  echo "[$(date -Is)] [$RUN step_$STEP gpu$GPU] FAIL: no adapter at $LORA_DIR" >&2
  exit 3
fi

# Special case: step_200 of every run already has _merged_latest. Reuse it instead of re-merging.
if [ "$STEP" = "200" ] && [ -f "$CKPT_DIR/_merged_latest/model.safetensors" ]; then
  USE_MODEL="$CKPT_DIR/_merged_latest"
  CLEANUP_AFTER=0
  echo "[$(date -Is)] [$RUN step_$STEP gpu$GPU] reusing _merged_latest" | tee -a "$LOG"
else
  USE_MODEL="$MERGED_DIR"
  CLEANUP_AFTER=1
  if [ ! -f "$MERGED_DIR/model.safetensors" ] && [ ! -f "$MERGED_DIR/model.safetensors.index.json" ]; then
    echo "[$(date -Is)] [$RUN step_$STEP gpu$GPU] merging LoRA on CPU..." | tee -a "$LOG"
    cd "$BASE"
    CUDA_VISIBLE_DEVICES="" \
    \
    HF_HUB_OFFLINE=1 \
    TRANSFORMERS_OFFLINE=1 \
    python - <<PY 2>&1 | tee -a "$LOG"
import os, torch
from transformers import AutoModelForCausalLM, AutoTokenizer
from peft import PeftModel

lora_dir = "$LORA_DIR"
merged_dir = "$MERGED_DIR"
import json
with open(os.path.join(lora_dir, "adapter_config.json")) as f:
    cfg = json.load(f)
base_id = cfg["base_model_name_or_path"]
print(f"merging {lora_dir} onto {base_id} -> {merged_dir}")
base = AutoModelForCausalLM.from_pretrained(base_id, torch_dtype=torch.bfloat16, device_map="cpu")
model = PeftModel.from_pretrained(base, lora_dir)
merged = model.merge_and_unload()
os.makedirs(merged_dir, exist_ok=True)
merged.save_pretrained(merged_dir, safe_serialization=True)
AutoTokenizer.from_pretrained(base_id, trust_remote_code=True).save_pretrained(merged_dir)
print("merge done")
PY
  else
    echo "[$(date -Is)] [$RUN step_$STEP gpu$GPU] merged dir exists, reusing" | tee -a "$LOG"
  fi
fi

cd "$BASE"

echo "[$(date -Is)] [$RUN step_$STEP gpu$GPU] running vLLM eval on GPU $GPU..." | tee -a "$LOG"
CUDA_VISIBLE_DEVICES=$GPU \
\
TOKENIZERS_PARALLELISM=false \
python eval_math500.py \
  --model "$USE_MODEL" \
  --output_dir "$EVAL_DIR" \
  --n_samples 4 --temperature 0.7 \
  --max_new_tokens 8192 --max_model_len 10240 \
  --gpu_memory_utilization 0.85 \
  >> "$LOG" 2>&1
rc=$?

if [ $rc -ne 0 ]; then
  echo "[$(date -Is)] [$RUN step_$STEP gpu$GPU] EVAL FAILED rc=$rc" | tee -a "$LOG" >&2
  exit $rc
fi

if [ ! -f "$EVAL_DIR/summary.json" ]; then
  echo "[$(date -Is)] [$RUN step_$STEP gpu$GPU] WARN: eval finished but no summary.json" | tee -a "$LOG" >&2
fi

# Cleanup merged dir to save disk
if [ $CLEANUP_AFTER -eq 1 ] && [ -d "$MERGED_DIR" ]; then
  echo "[$(date -Is)] [$RUN step_$STEP gpu$GPU] removing $MERGED_DIR" | tee -a "$LOG"
  rm -rf "$MERGED_DIR"
fi

echo "[$(date -Is)] [$RUN step_$STEP gpu$GPU] DONE" | tee -a "$LOG"
