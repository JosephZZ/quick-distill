#!/usr/bin/env bash
# Pair 2, full-seq LoRA: Qwen2.5-32B-Instruct × Qwen3.5-35B-A3B
set -eo pipefail

BASE="$(cd "$(dirname "$0")/.." && pwd)"
cd $BASE
export TOKENIZERS_PARALLELISM=false
export WANDB_MODE=disabled

STUDENT="Qwen/Qwen2.5-32B-Instruct"
TEACHER="Qwen/Qwen3.5-35B-A3B"
RUN=pair2-32b-q35-35b-fullseq
mkdir -p logs checkpoints

python on_policy_distill_positional.py \
  --student_model "$STUDENT" --teacher_model "$TEACHER" \
  --dataset AI-MO/NuminaMath-CoT --num_problems 3200 \
  --bs 16 --n_samples 1 --mini_bs 1 \
  --position_limit 0 --max_new_tokens 1024 \
  --token_select_mode prefix \
  --lora_r 32 --lora_alpha 64 \
  --lr 5e-5 --temperature 0.7 \
  --save_steps 50 --log_steps 10 --eval_steps 0 \
  --teacher_micro_bs 1 --gen_batch_size 4 \
  --student_gpu 2 --teacher_gpu 3 --vllm_gpu 2 \
  --vllm_gpu_util 0.55 \
  --use_vllm \
  --system_prompt "Please reason step by step, and put your final answer within \\boxed{}." \
  --output_dir "$BASE/checkpoints/$RUN" \
  --wandb_run_name "$RUN" \
  2>&1 | tee "$BASE/logs/$RUN.log"
