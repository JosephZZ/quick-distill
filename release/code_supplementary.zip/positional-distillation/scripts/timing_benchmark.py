"""
Timing benchmark: pos-100 vs fullseq, 1-GPU vs 2-GPU
Teacher: Qwen3-1.7B, Student: Qwen2.5-Math-1.5B
Measures: generation, model offload/reload, scoring, training, data transfer
"""
import torch
import time
import gc
import json
import os
import sys
import random
from transformers import AutoModelForCausalLM, AutoTokenizer
from peft import LoraConfig, TaskType, get_peft_model
from torch.nn.functional import log_softmax, kl_div
from datasets import load_dataset

def measure_time(fn, name=""):
    torch.cuda.synchronize()
    t0 = time.time()
    result = fn()
    torch.cuda.synchronize()
    elapsed = time.time() - t0
    return result, elapsed

def run_benchmark():
    SM = "Qwen/Qwen2.5-Math-1.5B"
    TM = "Qwen/Qwen3-1.7B"
    
    # Load dataset
    dataset = load_dataset("AI-MO/NuminaMath-CoT", split="train", streaming=False)
    problems = random.sample(list(dataset), 100)
    
    tokenizer = AutoTokenizer.from_pretrained(SM, trust_remote_code=True)
    sys_prompt = "Please reason step by step, and put your final answer within \\boxed{}."
    
    # Nothink ids for Qwen3
    _nothink_str = "<think>\n\n</think>\n\n"
    nothink_ids = tokenizer.encode(_nothink_str, add_special_tokens=False)
    
    lora_config = LoraConfig(
        task_type=TaskType.CAUSAL_LM, r=32, lora_alpha=64, lora_dropout=0.05,
        target_modules=["q_proj", "k_proj", "v_proj", "o_proj", "gate_proj", "up_proj", "down_proj"],
    )
    
    results = {}
    N_BATCHES = 5
    BS = 16  # problems per batch
    
    # ============================================================
    # Config 1: Pos-100, both models on GPU 1
    # ============================================================
    print("\n" + "="*60)
    print("CONFIG 1: Pos-100, both models on GPU 1")
    print("="*60)
    
    student = AutoModelForCausalLM.from_pretrained(SM, torch_dtype=torch.bfloat16).to("cuda:1")
    student = get_peft_model(student, lora_config)
    student.train()
    teacher = AutoModelForCausalLM.from_pretrained(TM, torch_dtype=torch.bfloat16).to("cuda:1")
    teacher.eval()
    
    optimizer = torch.optim.AdamW(student.parameters(), lr=5e-5)
    
    gen_times, score_times, train_times = [], [], []
    
    for batch_i in range(N_BATCHES):
        chunk = problems[batch_i*BS:(batch_i+1)*BS]
        
        # Build prompts
        prompts_ids = []
        for p in chunk:
            msgs = [{"role": "system", "content": sys_prompt}, {"role": "user", "content": p["problem"]}]
            prompt = tokenizer.apply_chat_template(msgs, tokenize=False, add_generation_prompt=True)
            ids = tokenizer(prompt, return_tensors="pt")["input_ids"][0].tolist()
            prompts_ids.append(ids)
        
        # Generation (HF generate, max 100 tokens for pos-100)
        def gen():
            trajs = []
            for ids in prompts_ids:
                input_ids = torch.tensor([ids], device="cuda:1")
                with torch.no_grad():
                    out = student.generate(input_ids, max_new_tokens=100, temperature=0.7, do_sample=True)
                resp_ids = out[0][len(ids):].tolist()
                trajs.append({"prompt_ids": ids, "response_ids": resp_ids})
            return trajs
        trajs, gen_t = measure_time(gen, "gen")
        gen_times.append(gen_t)
        
        # Scoring (teacher forward on GPU 1)
        def score():
            all_lps = []
            for traj in trajs:
                full_ids = traj["prompt_ids"] + nothink_ids + traj["response_ids"]
                resp_start = len(traj["prompt_ids"]) + len(nothink_ids)
                input_ids = torch.tensor([full_ids], device="cuda:1")
                with torch.no_grad(), torch.autocast(device_type="cuda", dtype=torch.bfloat16):
                    outputs = teacher(input_ids=input_ids)
                shift_logits = outputs.logits[0, :-1, :]
                lps = log_softmax(shift_logits.float(), dim=-1)
                start = resp_start - 1
                eff_len = min(len(traj["response_ids"]), 100)
                all_lps.append(lps[start:start+eff_len].cpu())
                del input_ids, outputs
            return all_lps
        teacher_lps, score_t = measure_time(score, "score")
        score_times.append(score_t)
        
        # Training
        def train_step():
            optimizer.zero_grad()
            total_loss = 0
            for traj, t_lp in zip(trajs, teacher_lps):
                full_ids = traj["prompt_ids"] + traj["response_ids"]
                input_ids = torch.tensor([full_ids], device="cuda:1")
                outputs = student(input_ids=input_ids, use_cache=False)
                logits = outputs.logits
                shift_logits = logits[0, :-1, :]
                resp_start = len(traj["prompt_ids"]) - 1
                eff_len = min(len(traj["response_ids"]), 100)
                s_lps = log_softmax(shift_logits[resp_start:resp_start+eff_len].float(), dim=-1)
                t_lp_dev = t_lp.to("cuda:1")
                min_v = min(s_lps.shape[-1], t_lp_dev.shape[-1])
                loss = kl_div(t_lp_dev[..., :min_v], s_lps[..., :min_v], log_target=True, reduction="batchmean")
                (loss / len(trajs)).backward()
                total_loss += loss.item()
                del input_ids, outputs
            torch.nn.utils.clip_grad_norm_(student.parameters(), 1.0)
            optimizer.step()
            return total_loss / len(trajs)
        try:
            loss, train_t = measure_time(train_step, "train")
        except torch.cuda.OutOfMemoryError:
            print(f"  Batch {batch_i+1}/{N_BATCHES}: TRAINING OOM - skipping")
            gc.collect(); torch.cuda.empty_cache()
            train_times.append(0); continue
        train_times.append(train_t)
        
        print(f"  Batch {batch_i+1}/{N_BATCHES}: gen={gen_t:.1f}s score={score_t:.1f}s train={train_t:.1f}s total={gen_t+score_t+train_t:.1f}s")
    
    results["pos100_1gpu"] = {
        "gen": gen_times, "score": score_times, "train": train_times,
        "avg_gen": sum(gen_times)/len(gen_times),
        "avg_score": sum(score_times)/len(score_times),
        "avg_train": sum(train_times)/len(train_times),
        "offload": 0, "reload": 0, "transfer": 0,
    }
    
    del student, teacher, optimizer
    gc.collect(); torch.cuda.empty_cache()
    
    # ============================================================
    # Config 2: Fullseq, both models on GPU 1 (need offload for gen)
    # ============================================================
    print("\n" + "="*60)
    print("CONFIG 2: Fullseq, 1-GPU (student+teacher on GPU 1, offload for gen)")
    print("="*60)
    
    student = AutoModelForCausalLM.from_pretrained(SM, torch_dtype=torch.bfloat16).to("cuda:1")
    student = get_peft_model(student, lora_config)
    student.train()
    teacher = AutoModelForCausalLM.from_pretrained(TM, torch_dtype=torch.bfloat16).to("cuda:1")
    teacher.eval()
    optimizer = torch.optim.AdamW(student.parameters(), lr=5e-5)
    
    gen_times, score_times, train_times, offload_times, reload_times = [], [], [], [], []
    
    for batch_i in range(N_BATCHES):
        chunk = problems[batch_i*BS:(batch_i+1)*BS]
        prompts_ids = []
        for p in chunk:
            msgs = [{"role": "system", "content": sys_prompt}, {"role": "user", "content": p["problem"]}]
            prompt = tokenizer.apply_chat_template(msgs, tokenize=False, add_generation_prompt=True)
            ids = tokenizer(prompt, return_tensors="pt")["input_ids"][0].tolist()
            prompts_ids.append(ids)
        
        # Offload both models to CPU
        def offload():
            student.to("cpu"); teacher.to("cpu")
            gc.collect(); torch.cuda.empty_cache()
        _, offload_t = measure_time(offload, "offload")
        offload_times.append(offload_t)
        
        # Generation (HF generate on GPU 1, fullseq = 3584 tokens)
        # Need to reload student temporarily for generation
        def gen_fullseq():
            student.to("cuda:1")
            trajs = []
            for ids in prompts_ids:
                input_ids = torch.tensor([ids], device="cuda:1")
                with torch.no_grad():
                    out = student.generate(input_ids, max_new_tokens=3584, temperature=0.7, do_sample=True)
                resp_ids = out[0][len(ids):].tolist()
                trajs.append({"prompt_ids": ids, "response_ids": resp_ids})
            student.to("cpu")
            gc.collect(); torch.cuda.empty_cache()
            return trajs
        trajs, gen_t = measure_time(gen_fullseq, "gen")
        gen_times.append(gen_t)
        
        # Reload both models
        def reload():
            student.to("cuda:1"); teacher.to("cuda:1")
        _, reload_t = measure_time(reload, "reload")
        reload_times.append(reload_t)
        
        # Scoring
        def score():
            all_lps = []
            for traj in trajs:
                full_ids = traj["prompt_ids"] + nothink_ids + traj["response_ids"]
                resp_start = len(traj["prompt_ids"]) + len(nothink_ids)
                input_ids = torch.tensor([full_ids], device="cuda:1")
                with torch.no_grad(), torch.autocast(device_type="cuda", dtype=torch.bfloat16):
                    outputs = teacher(input_ids=input_ids)
                shift_logits = outputs.logits[0, :-1, :]
                lps = log_softmax(shift_logits.float(), dim=-1)
                start = resp_start - 1
                all_lps.append(lps[start:start+len(traj["response_ids"])].cpu())
                del input_ids, outputs
            return all_lps
        teacher_lps, score_t = measure_time(score, "score")
        score_times.append(score_t)
        
        # Training
        def train_step():
            optimizer.zero_grad()
            total_loss = 0
            for traj, t_lp in zip(trajs, teacher_lps):
                full_ids = traj["prompt_ids"] + traj["response_ids"]
                input_ids = torch.tensor([full_ids], device="cuda:1")
                outputs = student(input_ids=input_ids, use_cache=False)
                logits = outputs.logits
                shift_logits = logits[0, :-1, :]
                resp_start = len(traj["prompt_ids"]) - 1
                s_lps = log_softmax(shift_logits[resp_start:resp_start+len(traj["response_ids"])].float(), dim=-1)
                t_lp_dev = t_lp.to("cuda:1")
                min_v = min(s_lps.shape[-1], t_lp_dev.shape[-1])
                loss = kl_div(t_lp_dev[..., :min_v], s_lps[..., :min_v], log_target=True, reduction="batchmean")
                (loss / len(trajs)).backward()
                total_loss += loss.item()
                del input_ids, outputs
            torch.nn.utils.clip_grad_norm_(student.parameters(), 1.0)
            optimizer.step()
            return total_loss / len(trajs)
        try:
            loss, train_t = measure_time(train_step, "train")
        except torch.cuda.OutOfMemoryError:
            print(f"  Batch {batch_i+1}/{N_BATCHES}: TRAINING OOM - skipping")
            gc.collect(); torch.cuda.empty_cache()
            train_times.append(0); continue
        train_times.append(train_t)
        
        total = offload_t + gen_t + reload_t + score_t + train_t
        print(f"  Batch {batch_i+1}/{N_BATCHES}: offload={offload_t:.1f}s gen={gen_t:.1f}s reload={reload_t:.1f}s score={score_t:.1f}s train={train_t:.1f}s total={total:.1f}s")
    
    results["fullseq_1gpu"] = {
        "gen": gen_times, "score": score_times, "train": train_times,
        "offload": offload_times, "reload": reload_times,
        "avg_gen": sum(gen_times)/len(gen_times),
        "avg_score": sum(score_times)/len(score_times),
        "avg_train": sum(train_times)/len(train_times),
        "avg_offload": sum(offload_times)/len(offload_times),
        "avg_reload": sum(reload_times)/len(reload_times),
        "transfer": 0,
    }
    
    del student, teacher, optimizer
    gc.collect(); torch.cuda.empty_cache()
    
    # ============================================================
    # Config 3: Fullseq, 2-GPU (student GPU1, teacher GPU0)
    # ============================================================
    print("\n" + "="*60)
    print("CONFIG 3: Fullseq, 2-GPU (student=GPU1, teacher=GPU0)")
    print("="*60)
    
    student = AutoModelForCausalLM.from_pretrained(SM, torch_dtype=torch.bfloat16).to("cuda:1")
    student = get_peft_model(student, lora_config)
    student.train()
    teacher = AutoModelForCausalLM.from_pretrained(TM, torch_dtype=torch.bfloat16).to("cuda:0")
    teacher.eval()
    optimizer = torch.optim.AdamW(student.parameters(), lr=5e-5)
    
    gen_times, score_times, train_times, transfer_times = [], [], [], []
    
    for batch_i in range(N_BATCHES):
        chunk = problems[batch_i*BS:(batch_i+1)*BS]
        prompts_ids = []
        for p in chunk:
            msgs = [{"role": "system", "content": sys_prompt}, {"role": "user", "content": p["problem"]}]
            prompt = tokenizer.apply_chat_template(msgs, tokenize=False, add_generation_prompt=True)
            ids = tokenizer(prompt, return_tensors="pt")["input_ids"][0].tolist()
            prompts_ids.append(ids)
        
        # Generation (student on GPU1, fullseq)
        def gen_fullseq():
            trajs = []
            for ids in prompts_ids:
                input_ids = torch.tensor([ids], device="cuda:1")
                with torch.no_grad():
                    out = student.generate(input_ids, max_new_tokens=3584, temperature=0.7, do_sample=True)
                resp_ids = out[0][len(ids):].tolist()
                trajs.append({"prompt_ids": ids, "response_ids": resp_ids})
            return trajs
        trajs, gen_t = measure_time(gen_fullseq, "gen")
        gen_times.append(gen_t)
        
        # Scoring (teacher on GPU0, need to transfer data)
        def score_2gpu():
            all_lps = []
            transfer_t = 0
            for traj in trajs:
                full_ids = traj["prompt_ids"] + nothink_ids + traj["response_ids"]
                resp_start = len(traj["prompt_ids"]) + len(nothink_ids)
                input_ids = torch.tensor([full_ids], device="cuda:0")  # on teacher GPU
                with torch.no_grad(), torch.autocast(device_type="cuda", dtype=torch.bfloat16):
                    outputs = teacher(input_ids=input_ids)
                shift_logits = outputs.logits[0, :-1, :]
                lps = log_softmax(shift_logits.float(), dim=-1)
                start = resp_start - 1
                lp_cpu = lps[start:start+len(traj["response_ids"])].cpu()
                all_lps.append(lp_cpu)
                del input_ids, outputs
            return all_lps, transfer_t
        (teacher_lps, xfer_t), score_t = measure_time(score_2gpu, "score")
        score_times.append(score_t)
        
        # Transfer: teacher logprobs CPU -> GPU1 (measured in training)
        def train_step_2gpu():
            optimizer.zero_grad()
            total_loss = 0
            xfer_time = 0
            for traj, t_lp in zip(trajs, teacher_lps):
                full_ids = traj["prompt_ids"] + traj["response_ids"]
                input_ids = torch.tensor([full_ids], device="cuda:1")
                outputs = student(input_ids=input_ids, use_cache=False)
                logits = outputs.logits
                shift_logits = logits[0, :-1, :]
                resp_start = len(traj["prompt_ids"]) - 1
                s_lps = log_softmax(shift_logits[resp_start:resp_start+len(traj["response_ids"])].float(), dim=-1)
                
                torch.cuda.synchronize()
                t0 = time.time()
                t_lp_dev = t_lp.to("cuda:1")
                torch.cuda.synchronize()
                xfer_time += time.time() - t0
                
                min_v = min(s_lps.shape[-1], t_lp_dev.shape[-1])
                loss = kl_div(t_lp_dev[..., :min_v], s_lps[..., :min_v], log_target=True, reduction="batchmean")
                (loss / len(trajs)).backward()
                total_loss += loss.item()
                del input_ids, outputs
            torch.nn.utils.clip_grad_norm_(student.parameters(), 1.0)
            optimizer.step()
            return total_loss / len(trajs), xfer_time
        (loss, xfer_t), train_t = measure_time(train_step_2gpu, "train")
        train_times.append(train_t)
        transfer_times.append(xfer_t)
        
        total = gen_t + score_t + train_t
        print(f"  Batch {batch_i+1}/{N_BATCHES}: gen={gen_t:.1f}s score={score_t:.1f}s train={train_t:.1f}s (xfer={xfer_t:.2f}s) total={total:.1f}s")
    
    results["fullseq_2gpu"] = {
        "gen": gen_times, "score": score_times, "train": train_times, "transfer": transfer_times,
        "avg_gen": sum(gen_times)/len(gen_times),
        "avg_score": sum(score_times)/len(score_times),
        "avg_train": sum(train_times)/len(train_times),
        "avg_transfer": sum(transfer_times)/len(transfer_times),
        "offload": 0, "reload": 0,
    }
    
    # ============================================================
    # Summary
    # ============================================================
    print("\n" + "="*60)
    print("SUMMARY (average over 5 batches, 16 problems/batch)")
    print("="*60)
    
    for config_name, data in results.items():
        total = data["avg_gen"] + data["avg_score"] + data["avg_train"]
        if data.get("avg_offload", 0) > 0:
            total += data["avg_offload"] + data["avg_reload"]
        print(f"\n{config_name}:")
        print(f"  Generation:     {data['avg_gen']:.1f}s")
        if data.get("avg_offload", 0) > 0:
            print(f"  Model offload:  {data['avg_offload']:.1f}s")
            print(f"  Model reload:   {data['avg_reload']:.1f}s")
        print(f"  Teacher scoring: {data['avg_score']:.1f}s")
        print(f"  Training:       {data['avg_train']:.1f}s")
        if data.get("avg_transfer", 0) > 0:
            print(f"  Data transfer:  {data['avg_transfer']:.2f}s")
        print(f"  TOTAL:          {total:.1f}s/step")
    
    # Save
    os.makedirs("checkpoints/timing_benchmark", exist_ok=True)
    with open("checkpoints/timing_benchmark/results.json", "w") as f:
        json.dump(results, f, indent=2)
    print("\nResults saved to checkpoints/timing_benchmark/results.json")

if __name__ == "__main__":
    run_benchmark()
