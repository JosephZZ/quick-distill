"""
Mass-based coverage for token-selection strategies (MPS port).

For each trajectory:
  coverage_S(strategy) = sum_{i in selected_K} S[i]  /  sum_{i over all positions} S[i]
where S is one of {KL, H_student, H_teacher}.
Then average across trajectories.

Strategies covered:
  prefix, top_kl, top_kl_200, ent_student, ent_student_200, ent_teacher,
  ent_and (H_s*H_t), ent_or (H_s+H_t), ent_kl_and (H_s*H_t*KL), hi_kl_hi_ent_topk (KL*full-vocab H),
  random, middle, last.

Usage (local MPS, small models):
  python scripts/analysis/strategy_mass_coverage_mps.py \
    --student_model Qwen/Qwen2.5-Math-1.5B \
    --teacher_model Qwen/Qwen3-1.7B \
    --num_problems 80 --max_new_tokens 512 \
    --output results/v1_verified/token_selection_mass_coverage.json
"""

import argparse, gc, json, os, sys
import torch
import numpy as np
from torch.nn.functional import log_softmax
from transformers import AutoTokenizer, AutoModelForCausalLM
from datasets import load_dataset

sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.dirname(os.path.abspath(__file__)))))
from on_policy_distill_positional import build_prompt

DEVICE = "cuda" if torch.cuda.is_available() else "cpu"


def _empty_cache():
    if torch.cuda.is_available():
        torch.cuda.empty_cache()


def main():
    p = argparse.ArgumentParser()
    p.add_argument("--student_model", required=True)
    p.add_argument("--teacher_model", required=True)
    p.add_argument("--num_problems", type=int, default=80)
    p.add_argument("--max_new_tokens", type=int, default=512)
    p.add_argument("--k", type=int, default=100)
    p.add_argument("--k2", type=int, default=200)
    p.add_argument("--output", type=str, default=None)
    args = p.parse_args()

    K, K2 = args.k, args.k2
    stok = AutoTokenizer.from_pretrained(args.student_model, trust_remote_code=True)
    ttok = AutoTokenizer.from_pretrained(args.teacher_model, trust_remote_code=True)

    # No-think tokens for Qwen3 teacher
    nothink = "<think>\n\n</think>\n\n"
    t_nothink_ids = ttok.encode(nothink, add_special_tokens=False) if "Qwen3" in args.teacher_model else []
    s_nothink_ids = stok.encode(nothink, add_special_tokens=False) if "Qwen3" in args.student_model else []

    ds = load_dataset("AI-MO/NuminaMath-CoT", split="train")
    problems = [ds[i]["problem"] for i in range(args.num_problems)]

    print(f"Phase 1: student gen on {DEVICE}")
    student = AutoModelForCausalLM.from_pretrained(
        args.student_model, torch_dtype=torch.bfloat16, trust_remote_code=True).to(DEVICE)

    traj = []
    for pi, problem in enumerate(problems):
        prompt = build_prompt(problem, stok)
        in_ids = stok.encode(prompt, add_special_tokens=False)
        x = torch.tensor([in_ids], device=DEVICE)
        with torch.no_grad():
            out = student.generate(x, max_new_tokens=args.max_new_tokens, temperature=0.7,
                                   do_sample=True, pad_token_id=stok.eos_token_id)
        resp = out[0][len(in_ids):].tolist()
        if len(resp) < K + 10:
            continue
        full = in_ids + s_nothink_ids + resp
        with torch.no_grad():
            logits = student(torch.tensor([full], device=DEVICE)).logits[0]
        resp_start = len(in_ids) + len(s_nothink_ids)
        s_lp = log_softmax(logits[resp_start - 1:-1].float(), dim=-1).cpu()
        traj.append({"in_ids": in_ids, "resp": resp, "s_lp": s_lp})
        if (pi + 1) % 10 == 0:
            print(f"  student {pi+1}/{args.num_problems}  kept={len(traj)}")

    del student; gc.collect(); _empty_cache()

    print(f"Phase 2: teacher score on {DEVICE} (n={len(traj)})")
    teacher = AutoModelForCausalLM.from_pretrained(
        args.teacher_model, torch_dtype=torch.bfloat16, trust_remote_code=True).to(DEVICE)

    strategies = ["prefix", "top_kl_100", "top_kl_200", "ent_student_100", "ent_student_200",
                  "ent_teacher_100", "ent_and_100", "ent_or_100", "ent_kl_and_100",
                  "hi_kl_hi_ent_topk_100", "random_100", "middle_100", "last_100"]
    # coverage buckets: {strat: {"kl": [], "hs": [], "ht": [], "pos": []}}
    acc = {s: {"kl": [], "hs": [], "ht": [], "pos": []} for s in strategies}

    for di, t in enumerate(traj):
        in_ids, resp, s_lp = t["in_ids"], t["resp"], t["s_lp"]
        t_full = in_ids + t_nothink_ids + resp
        t_resp_start = len(in_ids) + len(t_nothink_ids)
        with torch.no_grad():
            t_logits = teacher(torch.tensor([t_full], device=DEVICE)).logits[0]
        t_lp = log_softmax(t_logits[t_resp_start - 1:-1].float(), dim=-1).cpu()

        rlen = min(len(resp), t_lp.shape[0], s_lp.shape[0])
        if rlen < max(K, 50):
            continue
        V = min(s_lp.shape[-1], t_lp.shape[-1])
        sl, tl = s_lp[:rlen, :V], t_lp[:rlen, :V]
        sp, tp = torch.exp(sl), torch.exp(tl)
        kl = (sp * (sl - tl)).sum(-1).clamp(min=0)
        hs = -(sp * sl).sum(-1)
        ht = -(tp * tl).sum(-1)
        # Joint score for hi_kl_hi_ent: KL * (H_s * H_t) — matches ent_kl_and form
        joint_kl_ent = kl * (hs * ht).clamp(min=0)

        tot_kl = kl.sum().item()
        tot_hs = hs.sum().item()
        tot_ht = ht.sum().item()
        if tot_kl < 1e-6 or tot_hs < 1e-6 or tot_ht < 1e-6:
            continue

        def record(name, idx):
            acc[name]["kl"].append(kl[idx].sum().item() / tot_kl * 100)
            acc[name]["hs"].append(hs[idx].sum().item() / tot_hs * 100)
            acc[name]["ht"].append(ht[idx].sum().item() / tot_ht * 100)
            acc[name]["pos"].append(idx.float().mean().item())

        k = min(K, rlen); k2 = min(K2, rlen)
        record("prefix", torch.arange(k))
        record("top_kl_100", torch.topk(kl, k=k).indices)
        record("top_kl_200", torch.topk(kl, k=k2).indices)
        record("ent_student_100", torch.topk(hs, k=k).indices)
        record("ent_student_200", torch.topk(hs, k=k2).indices)
        record("ent_teacher_100", torch.topk(ht, k=k).indices)
        record("ent_and_100", torch.topk(hs * ht, k=k).indices)
        record("ent_or_100", torch.topk(hs + ht, k=k).indices)
        record("ent_kl_and_100", torch.topk((hs * ht).clamp(min=0) * kl.clamp(min=0), k=k).indices)
        record("hi_kl_hi_ent_topk_100", torch.topk(joint_kl_ent, k=k).indices)
        record("random_100", torch.randperm(rlen)[:k])
        mid = rlen // 2
        record("middle_100", torch.arange(max(0, mid - k // 2), max(0, mid - k // 2) + k))
        record("last_100", torch.arange(rlen - k, rlen))

        if (di + 1) % 10 == 0:
            print(f"  teacher {di+1}/{len(traj)}")

    del teacher; gc.collect(); _empty_cache()

    print(f"\n{'strategy':<24} {'KL%':>7} {'H_s%':>7} {'H_t%':>7} {'pos':>7}")
    print("-" * 58)
    results = {}
    for s in strategies:
        if not acc[s]["kl"]:
            continue
        row = {
            "kl_mass_pct": float(np.mean(acc[s]["kl"])),
            "hs_mass_pct": float(np.mean(acc[s]["hs"])),
            "ht_mass_pct": float(np.mean(acc[s]["ht"])),
            "avg_position": float(np.mean(acc[s]["pos"])),
            "n_traj": len(acc[s]["kl"]),
        }
        results[s] = row
        print(f"{s:<24} {row['kl_mass_pct']:>7.2f} {row['hs_mass_pct']:>7.2f} {row['ht_mass_pct']:>7.2f} {row['avg_position']:>7.1f}")

    if args.output:
        os.makedirs(os.path.dirname(args.output), exist_ok=True)
        with open(args.output, "w") as f:
            json.dump(results, f, indent=2)
        print(f"\nSaved: {args.output}")


if __name__ == "__main__":
    main()
