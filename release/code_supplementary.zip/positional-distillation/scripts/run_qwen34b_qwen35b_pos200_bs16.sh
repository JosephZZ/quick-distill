#!/usr/bin/env bash
# Full fresh run: Qwen3-4B student + Qwen3.5-4B teacher, cross-tokenizer KL.
# Paper n1bs16 recipe: 3200 problems, bs=16, n_samples=1, 200 steps, LoRA pos-200.
# mini_bs=1 → 16 grad-accum per optimizer step (safe on 96GB unified memory).
set -eo pipefail
SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
BASE_DIR="$(cd "$SCRIPT_DIR/.." && pwd)"
cd "$BASE_DIR"

export PYTORCH_ENABLE_MPS_FALLBACK=1
export TOKENIZERS_PARALLELISM=false
export WANDB_MODE=${WANDB_MODE:-disabled}
export HF_HUB_OFFLINE=1
export TRANSFORMERS_OFFLINE=1
export HF_DATASETS_OFFLINE=1

STUDENT="Qwen/Qwen3-4B"
TEACHER="Qwen/Qwen3.5-4B"
VENV=".venv"

mkdir -p logs checkpoints
LOG="logs/run_qwen34b_qwen35b_pos200_bs16_$(date +%Y%m%d_%H%M%S).log"

echo "=== Qwen3-4B student + Qwen3.5-4B teacher, bs=16 n=1 × 200 steps (paper n1bs16 recipe) ===" | tee "$LOG"
echo "Started $(date)" | tee -a "$LOG"

$VENV/bin/python on_policy_distill_positional_mps.py \
  --student_model "$STUDENT" --teacher_model "$TEACHER" \
  --dataset "AI-MO/NuminaMath-CoT" --num_problems 3200 \
  --bs 16 --mini_bs 1 --n_samples 1 \
  --position_limit 200 --max_new_tokens 200 \
  --token_select_mode prefix \
  --lora_r 32 --lora_alpha 64 \
  --lr 5e-5 --save_steps 50 --log_steps 1 --eval_steps 0 \
  --warmup_ratio 0.05 \
  --temperature 0.7 --teacher_micro_bs 1 --gen_batch_size 1 \
  --seed 42 \
  --output_dir "checkpoints/qwen3-4b-qwen35-4b-pos200-bs16-n200" \
  --wandb_run_name "qwen3-4b-qwen35-4b-pos200-bs16-n200" \
  2>&1 | tee -a "$LOG"

echo "Finished $(date)" | tee -a "$LOG"
