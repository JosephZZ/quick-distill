#!/usr/bin/env bash
# Pair 1, prefix-100 LoRA: Qwen2.5-14B-Instruct (student) × Qwen3.5-35B-A3B (teacher)
# Math, paper-scale: 3200 problems × 200 steps × n=1 bs=16
set -eo pipefail

BASE="$(cd "$(dirname "$0")/.." && pwd)"
cd $BASE
export TOKENIZERS_PARALLELISM=false
export WANDB_MODE=disabled

STUDENT="Qwen/Qwen2.5-14B-Instruct"
TEACHER="Qwen/Qwen3.5-35B-A3B"
RUN=pair1-14b-q35-35b-prefix100
mkdir -p logs checkpoints

# GPUs: student+vLLM on 0, teacher on 1
python on_policy_distill_positional.py \
  --student_model "$STUDENT" --teacher_model "$TEACHER" \
  --dataset AI-MO/NuminaMath-CoT --num_problems 3200 \
  --bs 16 --n_samples 1 --mini_bs 1 \
  --position_limit 100 --max_new_tokens 100 \
  --token_select_mode prefix \
  --lora_r 32 --lora_alpha 64 \
  --lr 5e-5 --temperature 0.7 \
  --save_steps 50 --log_steps 10 --eval_steps 0 \
  --teacher_micro_bs 1 --gen_batch_size 4 \
  --student_gpu 0 --teacher_gpu 1 --vllm_gpu 0 \
  --vllm_gpu_util 0.55 \
  --use_vllm \
  --system_prompt "Please reason step by step, and put your final answer within \\boxed{}." \
  --output_dir "$BASE/checkpoints/$RUN" \
  --wandb_run_name "$RUN" \
  2>&1 | tee "$BASE/logs/$RUN.log"
