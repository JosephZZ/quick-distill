#!/usr/bin/env bash
# Cross-family + cross-tokenizer prefix-100 test:
# student = google/gemma-2-2b-it
# teacher = Qwen/Qwen3-4B
set -eo pipefail
BASE="$(cd "$(dirname "$0")/.." && pwd)"
cd $BASE
source ~/.hf_env
export TOKENIZERS_PARALLELISM=false
export WANDB_MODE=disabled
export CUDA_VISIBLE_DEVICES=4

STUDENT="google/gemma-2-2b-it"
TEACHER="Qwen/Qwen3-4B"
RUN=cross-gemma2-2b-qwen3-4b-math-prefix100
mkdir -p logs checkpoints

python on_policy_distill_positional.py \
  --student_model "$STUDENT" --teacher_model "$TEACHER" \
  --dataset AI-MO/NuminaMath-CoT --num_problems 3200 \
  --bs 16 --n_samples 1 --mini_bs 1 \
  --position_limit 100 --max_new_tokens 100 \
  --token_select_mode prefix \
  --lora_r 32 --lora_alpha 64 \
  --lr 5e-5 --temperature 0.7 \
  --save_steps 50 --log_steps 10 --eval_steps 0 \
  --teacher_micro_bs 4 \
  --student_gpu 0 --teacher_gpu 0 --vllm_gpu 0 \
  --vllm_gpu_util 0.0 \
  --system_prompt "Please reason step by step, and put your final answer within \\boxed{}." \
  --output_dir "$BASE/checkpoints/$RUN" \
  --wandb_run_name "$RUN" \
  2>&1 | tee "$BASE/logs/$RUN.log"
